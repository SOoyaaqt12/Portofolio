<x-app-layout>
    <section class="bg-white dark:bg-gray-900">
        <div class="grid max-w-screen-xl px-4 py-8 mx-auto my-16 lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">
            <div class="mr-auto place-self-center lg:col-span-7">
                <h1 class="max-w-2xl my-10 text-4xl font-extrabold tracking-tight leading-none md:text-5xl xl:text-6xl dark:text-white">DAFFA RAFIF RAMADHAN</h1>
                <p class="max-w-2xl mb-6 font-light text-gray-500 lg:my-10 md:text-lg lg:text-md dark:text-gray-400">Perkenalkan nama saya Daffa Rafif Ramadhan, Saya lahir di Depok pada tanggal 12 Oktober 2006, saat ini Saya tinggal di Bogor dan bersekolah di SMK Informatika PESAT, kelas 11 jurusan Rekayasa Perangkat Lunak.</p>
            </div>
            <div class="hidden shadow-gray-800 lg:mt-0 lg:col-span-5 lg:flex">
                <img src="{{ asset('storage/gambar/gambarsaya.jpeg') }}" class="rounded-3xl shadow-2xl" alt="mockup">
            </div>                
        </div>
    </section>
    <section class="bg-white dark:bg-gray-900">
        <div class="py-8 px-4 mx-auto max-w-screen-xl text-center lg:py-16 lg:px-12">
            <h1 class="mb-4 text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-5xl lg:text-6xl dark:text-white">Crafting Digital Experiences</h1>
            <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-16 xl:px-48 dark:text-gray-400">Sebagai seorang profesional yang berdedikasi di bidang Rekayasa Perangkat Lunak, saya menghadirkan karya yang kreatif, fungsional, dan berorientasi pada detail. Jelajahi proyek saya dan lihat bagaimana saya dapat membantu Anda mewujudkan ide menjadi nyata.</p>
            <div class="flex flex-col mb-8 lg:mb-16 space-y-4 sm:flex-row sm:justify-center sm:space-y-0 sm:space-x-4">
                <a href="https://github.com/SOoyaaqt12" class="shadow-2xl inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 dark:focus:ring-primary-900">
                    My Project
                </a>
                <a href="" class="shadow-2xl inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-gray-900 rounded-lg border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:text-white dark:border-gray-700 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
                    Watch video
                </a>  
            </div>
        </div>
    </section>
    
</x-app-layout>
